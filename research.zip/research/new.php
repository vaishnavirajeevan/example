<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "search";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
$mname=$_POST['id'];
$genre=$_POST['user'];
$director=$_POST['pass'];
$query = "INSERT INTO `reg` (id,name,password,) VALUES ('$mname', '$genre', '$director')";
        $result = mysqli_query($conn, $query);
		?>